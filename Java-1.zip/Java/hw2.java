

import com.sun.xml.internal.ws.util.StringUtils;
import java.text.*;
import javax.swing.*;
import java.io.*;
import java.lang.*;
import java.util.ArrayList;
/**
 *
 * @author Ben
 */
public class hw2 {

    public static void hw2(String input, String output)
    {
        try {
            ArrayList<String> l = new ArrayList<String>();
            String inputLine = null;
            String outputLine = null;
            String line = "";
            String lineOut = "";
            boolean pushFlag = false;
            
            FileWriter fileWriter = new FileWriter(output);   //opening write file stream
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);   //wrap fileWriter in buffer stream
            
            FileReader fileReader = new FileReader(input);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null)
            {   String[] word = line.split("\\s+");
            
            
                if(word[0].equals("push"))
                {
                    if(word[1].equals("-0"))
                        word[1] = "0";
                    l.add(word[1]);
                }
                else if(word[0].endsWith("pop")) 
                {
                    if(l.isEmpty())
                        l.add(":error:");
                    else
                        l.remove(l.size()-1);
                }
                else if(word[0].equals(":false:"))
                    l.add(":false:");
                else if(word[0].equals(":true:"))
                    l.add(":true:");
                else if(l.size() == 0)
                {
                    l.add(":error:");
                    continue;
                }
                else if(word[0].equals(":error:"))
                    l.add(":error:");
                else if(word[0].equals("neg"))
                {
                    String x = l.get(l.size()-1);
                    if(x.equals("0"))
                        continue;
                    else if(isNumeric(x.substring(0,1)))
                        l.set((l.size()-1),("-" + l.get(l.size()-1)));
                    else
                        l.set((l.size()-1),x.substring(1, x.length()));                        
                }
                else if(word[0].equals("add") || word[0].equals("sub") || word[0].equals("mul") || word[0].equals("div") || word[0].equals("rem"))
                {
                    if(l.size() < 2)
                    {
                        l.add(":error:");
                        continue;
                    }
                    String x = l.get(l.size()-1);
                    String y = l.get(l.size()-2);
                    if(isNumeric(x.substring(0,1)))
                            {
                                
                            }
                    else if(x.substring(0,1).equals( "-"))
                            {
                                
                            }
                    else
                        {
                            l.add(":error:");
                            continue;
                        }
                    if(isNumeric(y.substring(0,1)))
                    {
                        
                    }
                    else if(y.substring(0,1).equals( "-"))
                    {
                        
                    }
                    else
                        {
                            l.add(":error:");
                            continue;
                        }
                    if(word[0].equals("add"))
                    {
                        int xa = Integer.parseInt(l.get(l.size()-2)) + Integer.parseInt(l.get(l.size()-1));
                        l.remove(l.size()-1);
                        l.remove(l.size()-1);
                        l.add(Integer.toString(xa));
                    }
                    if(word[0].equals("sub"))
                    {
                        
                        int xs = Integer.parseInt(l.get(l.size()-2)) - Integer.parseInt(l.get(l.size()-1));
                        l.remove(l.size()-1);
                        l.remove(l.size()-1);
                        l.add(Integer.toString(xs));
                    }
                    if(word[0].equals("mul"))
                    {
                        int xm = Integer.parseInt(l.get(l.size()-2)) * Integer.parseInt(l.get(l.size()-1));
                        l.remove(l.size()-1);
                        l.remove(l.size()-1);
                        l.add(Integer.toString(xm));
                    }
                    if(word[0].equals("div"))
                    {
                        int test = Integer.parseInt(l.get(l.size()-1));
                        if(test == 0)
                        {
                            l.add(":error:");
                            continue;
                        }
                        int xd = Integer.parseInt(l.get(l.size()-2)) / Integer.parseInt(l.get(l.size()-1));
                        l.remove(l.size()-1);
                        l.remove(l.size()-1);
                        l.add(Integer.toString(xd));
                    }
                    else if(word[0].equals("rem"))
                    {
                        int test = Integer.parseInt(l.get(l.size()-2));
                        if(test == 0)
                        {
                            l.add(":error:");
                            continue;
                        }
                        int xmo = Integer.parseInt(l.get(l.size()-2)) % Integer.parseInt(l.get(l.size()-1));
                        l.remove(l.size()-1);
                        l.remove(l.size()-1);
                        l.add(Integer.toString(xmo));
                    }
                }
                else if(word[0].equals("swap"))
                {
                    if(l.size() < 2)
                    {
                        l.add(":error:");
                        continue;
                    }
                    
                    String temp = new String(l.get(l.size()-1));
                    String temp1 = new String( l.get(l.size()-2));
                    l.remove(l.size()-1);
                    l.remove(l.size()-1);
                    l.add(temp);
                    l.add(temp1);
                }
                
                else if(!(word[0].equals("quit")))
                {
                    l.add(":error:");
                    continue;
                }
                
            }
                
            
            
            
            
            
            
            
            
            /////////WRITE TO FILE//////////
            while(l.size() > 0)
            {
                if(l.get(l.size()-1) == "quit")
                    System.exit(0);
                System.out.println(l.get(l.size() - 1));
                bufferedWriter.write(l.get(l.size()-1) + "\n");
                l.remove(l.size() - 1);
            }
            bufferedWriter.close();
            bufferedReader.close();
        }
        catch(FileNotFoundException ex) {
            System.out.println("Error: " + ex);
        }
        catch(IOException ex) {
            System.out.println("Error: " + ex);
        }
        
    }
    
    public static boolean isNumeric(String str)  
    {  
        try  
        {  
            int i = Integer.parseInt(str);  
        } 
            catch(NumberFormatException e)  
        {  
            return false;  
        }  
            return true;  
    }
    
    
}
